# Project Start Date
  04/07/2023
    -3 hrs
  05/07/2023
    -3hr(9:30am to 12:30pm) + 
    - 3 hrs 30 mins (1:30pm to 5pm)
    -2hrs 45 mins(10:15pm to 1am)
  06/07/2023
    -10:30am to 2:15
    -3pm to 6pm 
    -10:17pm to 11:30pm
    this is for testing